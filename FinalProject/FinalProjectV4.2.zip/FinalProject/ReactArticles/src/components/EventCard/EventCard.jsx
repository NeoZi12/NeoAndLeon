import classes from "./EventCard.module.css";

export default function EventCard({ event }) {
  return (
    <div className={classes.eventCard} key={event.event_id}>
      <h2>{event.event_name}</h2>
      <p>{event.category}</p>
      <img src={event.img_src} alt="" />
    </div>
  );
}
