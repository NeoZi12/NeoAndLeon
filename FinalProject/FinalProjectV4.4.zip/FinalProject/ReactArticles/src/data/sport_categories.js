const sportCategories = [
  "Soccer",
  "Basketball",
  "Tennis",
  "Swimming",
  "Running",
  "Cycling",
  "Volleyball",
  "Martial Arts",
  "Gymnastics",
  "Walking",
  "Cards Games",
  "Handball",
  "Table Tennis",
  "Badminton",
  "Surfing",
  "Skateboarding",
];

export default sportCategories;
