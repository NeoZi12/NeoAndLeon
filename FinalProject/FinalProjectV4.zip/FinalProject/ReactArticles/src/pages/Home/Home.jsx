import classes from "./Home.module.css";
import axios from "axios";
import { useState, useEffect } from "react";

export default function Home() {
  const [events, setEvents] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = () => {
    axios
      .get("home")
      .then((res) => {
        setEvents(res.data);
        console.log(res.data); // Data from API
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  };
  return (
    <main>
      <div className={classes.homeHeader}>
        <h2>Home Page</h2>
      </div>
      <div className={classes.homeSearch}>
        <p>This is the search area</p>
      </div>
      <div className={classes.featuredEvents}>
        {events &&
          events.map((event) => {
            return (
              <div className={classes.eventCard} key={event.id}>
                <h2>{event.event_name}</h2>
                <p>{event.category}</p>
              </div>
            );
          })}
      </div>
      <div className={classes.mapAndFilter}>
        <div className={classes.filters}>
          <p>Here we will have filters</p>
        </div>
        <div className={classes.map}>
          <p>Here we will have a map</p>
        </div>
      </div>
    </main>
  );
}
