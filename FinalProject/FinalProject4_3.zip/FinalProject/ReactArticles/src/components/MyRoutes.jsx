import React from "react";
import { Routes, Route } from "react-router-dom";
import Header from "./Header/Header";
import Footer from "./Footer/Footer";
import Home from "../pages/Home/Home";
import classes from "./Page.module.css";
import NewEvent from "./forms/newEvent/newEvent";

export default function MyRoutes() {
  return (
    <>
      <Header />
      <main className={classes.page}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/home" element={<Home />} />
          <Route path="/newEvent" element={<NewEvent />} />
        </Routes>
      </main>

      <Footer />
    </>
  );
}
