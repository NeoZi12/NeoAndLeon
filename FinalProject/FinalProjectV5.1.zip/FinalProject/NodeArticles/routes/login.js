const express = require("express");
const dbSingleton = require("../dbSingleton");
const router = express.Router();
const db = dbSingleton.getConnection();

router.post("/register", (req, res) => {
  const { first_name, last_name, user_name, password, gender, city, email } =
    req.body;

  // Step 1: Query for existing emails
  const userEmailsQuery = `SELECT email FROM users WHERE email = ?`;

  db.query(userEmailsQuery, [email], (err, results) => {
    if (err) {
      console.error("Error checking existing email:", err);
      return res.status(500).json({ error: "Database error." });
    }

    if (results.length > 0)
      return res.status(400).json({ error: "Email already exists." });

    // Step 3: Insert new user
    const insertQuery = `
      INSERT INTO users (first_name, last_name, user_name, password, gender, city, email)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;
    const values = [
      first_name,
      last_name,
      user_name,
      password,
      gender,
      city,
      email,
    ];

    db.query(insertQuery, values, (err, results) => {
      if (err) {
        console.error("Error inserting user:", err);
        return res.status(500).json({ error: "Database error." });
      }

      res.status(201).json({ message: "User registered successfully." });
    });
  });
});

module.exports = router;
