import React from "react";
import classes from "./Header.module.css";
import NavBar from "../NavBar/NavBar";

export default function Header() {
  return (
    <header className={classes.header}>
      <div className={classes.headerContainer}>
        <div className={classes.logo}>Eventy</div>
        <div className={classes.nav}>
          <NavBar />
        </div>
      </div>
    </header>
  );
}
