const express = require("express");
const dbSingleton = require("../dbSingleton");
const router = express.Router();
const db = dbSingleton.getConnection();

router.get("/", (req, res) => {
  const query = `SELECT * 
FROM images
JOIN events
WHERE images.event_id=events.event_id;`;
  db.query(query, (err, results) => {
    if (err) {
      res.status(500).send(err);
      return;
    }
    res.json(results);
  });
});

// router.get("/", (req, res) => {
//   const events = [
//     {
//       id: 1,
//       title: "Football Game",
//       content: "5 a side football game",
//       img: "https://loremflickr.com/200/200?random=1",
//     },
//     {
//       id: 2,
//       title: "Poker match",
//       content: "6 man table poker match.",
//       img: "https://loremflickr.com/200/200?random=2",
//     },
//     {
//       id: 3,
//       title: "Basketball game",
//       content: "3v3 basketball game.",
//       img: "https://loremflickr.com/200/200?random=3",
//     },
//     {
//       id: 4,
//       title: "Basketball game",
//       content: "3v3 basketball game.",
//       img: "https://loremflickr.com/200/200?random=4",
//     },
//   ];
//   res.json(events);
// });

module.exports = router;
