import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import classes from "./EventView.module.css";

export default function EventView() {
  const [event, setEvent] = useState(null);
  const { id } = useParams();

  useEffect(() => {
    fetchData();
  }, [id]);

  const fetchData = () => {
    axios
      .get(`/event/${id}`)
      .then((res) => {
        setEvent(res.data);
      })
      .catch((error) => {
        console.error("Error fetching event:", error);
      });
  };

  const formatDate = (dateString) => {
    if (!dateString) return "-";
    const options = { year: "numeric", month: "2-digit", day: "2-digit" };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  const formatTime = (timeString) => {
    if (!timeString) return "-";
    return timeString.substring(0, 5);
  };

  if (!event) {
    return <p className={classes.loading}>Loading event details...</p>;
  }

  return (
    <div className={classes.eventContainer}>
      <h2 className={classes.eventTitle}>{event.event_name}</h2>
      <div className={classes.eventGrid}>
        <div>
          <strong>Event ID:</strong> {event.event_id}
        </div>
        <div>
          <strong>Category:</strong> {event.category || "-"}
        </div>
        <div>
          <strong>Start Date:</strong> {formatDate(event.start_date)}
        </div>
        <div>
          <strong>End Date:</strong> {formatDate(event.end_date)}
        </div>
        <div>
          <strong>Start Time:</strong> {formatTime(event.start_time)}
        </div>
        <div>
          <strong>City:</strong> {event.city || "-"}
        </div>
        <div>
          <strong>Participants:</strong> {event.participant_amount ?? "-"}
        </div>
        <div>
          <strong>Private:</strong> {event.is_private ? "Yes" : "No"}
        </div>
        <div>
          <img src={event.src} alt="" />
        </div>
      </div>
      <div>
        <h2>participants : </h2>
      </div>
    </div>
  );
}
