import React from "react";
import { NavLink } from "react-router-dom";
import classes from "./NavBar.module.css";

export default function NavBar() {
  return (
    <nav className={classes.navbar}>
      <NavLink
        to="/"
        className={({ isActive }) => (isActive ? classes.active : "")}
      >
        Home
      </NavLink>
      <NavLink
        to="/personal-area"
        className={({ isActive }) => (isActive ? classes.active : "")}
      >
        Personal Area
      </NavLink>
      <NavLink
        to="/login"
        className={({ isActive }) => (isActive ? classes.active : "")}
      >
        Login
      </NavLink>
    </nav>
  );
}
