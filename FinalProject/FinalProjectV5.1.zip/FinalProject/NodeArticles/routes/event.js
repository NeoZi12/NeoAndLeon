const express = require("express");
const dbSingleton = require("../dbSingleton");
const router = express.Router();
const db = dbSingleton.getConnection();

router.get("/:id", (req, res) => {
  const id = req.params.id;

  const query = `SELECT * 
    FROM events
     natural join default_images
    where  event_id= ${id} limit 1`;
  db.query(query, (err, results) => {
    if (err) {
      res.status(500).send(err);
      return;
    }
    res.json(results[0]);
  });
});
module.exports = router;
