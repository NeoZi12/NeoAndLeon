import classes from "./Home.module.css";

export default function Home() {
  return (
    <>
      <div className={classes.homeHeader}>
        <h2>Home Page</h2>
      </div>
      <div className={classes.homeSearch}>
        <p>This is the search area</p>
      </div>
      <div className={classes.featuredEvents}>
        <p>Here we will have featured events</p>
      </div>
      <div className={classes.mapAndFilter}>
        <div className={classes.filters}>
          <p>Here we will have filters</p>
        </div>
        <div className={classes.map}>
          <p>Here we will have a map</p>
        </div>
      </div>
    </>
  );
}
